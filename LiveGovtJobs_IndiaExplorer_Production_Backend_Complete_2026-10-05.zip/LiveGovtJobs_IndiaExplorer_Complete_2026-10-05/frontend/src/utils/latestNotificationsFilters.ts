import type { CategoryId } from '@/data/categories'
import { jobMatchesNationwideFilter, jobMatchesStateFilter } from '@/data/jobRegion'
import { NE_SUBSTATE_IDS, getLatestNotifStateChip } from '@/data/statesChips'
import { getProfessionBySlug, jobMatchesProfession } from '@/data/professions'
import { resolveJobCategory } from '@/utils/jobCategory'
import { resolveJobQualification } from '@/utils/jobQualification'
import { jobMatchesEducationFilterKey } from '@/utils/educationVacancySummary'
import { isJobExpired, parseLastDate } from '@/utils/jobFilters'
import type { JobRecord } from '@/types/job'

const DAY_MS = 86400000
export const EXPIRING_SOON_DAYS = 7

/** Category chips that route through profession matching (broader than category id alone). */
export const PROFESSION_CHIP_FOR_CATEGORY: Partial<Record<CategoryId, string>> = {
  health: 'medical',
  engineering: 'engineering',
}

/** Host/title hints for jobs still tagged with umbrella `ne` state code. */
const NE_SUBSTATE_HINTS: Record<string, RegExp> = {
  ar: /arunachal/i,
  mn: /manipur/i,
  ml: /meghalaya/i,
  mz: /mizoram/i,
  nl: /nagaland/i,
  tr: /tripura/i,
}

function jobStateProbe(job: JobRecord) {
  const detail = job?.detail as { notification_url?: string; summary?: string } | undefined
  return [
    job?.title,
    job?.dept,
    job?.about,
    detail?.summary,
    job?.applyUrl,
    detail?.notification_url,
  ]
    .filter(Boolean)
    .join(' ')
}

function neSubstateFromJob(job: JobRecord): string | null {
  const probe = jobStateProbe(job)
  for (const id of NE_SUBSTATE_IDS) {
    if (NE_SUBSTATE_HINTS[id]?.test(probe)) return id
  }
  return null
}

/** State filter for latest-notifications chips (36 states/UTs + NE split). */
export function jobMatchesLatestNotifStateFilter(job: JobRecord, stateId: string | null): boolean {
  if (!stateId) return true
  if (stateId === 'all') return jobMatchesNationwideFilter(job)
  if (jobMatchesStateFilter(job, stateId)) return true

  const ids = job?.stateIds
  if (!Array.isArray(ids) || !ids.includes('ne')) return false
  if (!NE_SUBSTATE_HINTS[stateId]) return false
  return neSubstateFromJob(job) === stateId
}

export type LatestNotifJobFilter = {
  stateId?: string | null
  categoryId?: CategoryId | null
  professionSlug?: string | null
  quickFilter?: string | null
  expiringOnly?: boolean
  expiringWithinDays?: number
  deadlineWindow?: 'all' | 'today' | 'tomorrow' | 'week' | 'date'
  deadlineDate?: string | null
}

export function jobLastDateIso(job: JobRecord): string | null {
  const raw = String(job?.lastDate || '').slice(0, 10)
  return /^\d{4}-\d{2}-\d{2}$/.test(raw) ? raw : null
}

export function indiaDateIso(nowMs: number = Date.now()): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Kolkata',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(nowMs))
}

export function addCalendarDays(iso: string, days: number): string {
  const [year, month, day] = iso.split('-').map(Number)
  return new Date(Date.UTC(year, month - 1, day + days)).toISOString().slice(0, 10)
}

export function daysUntilDeadline(job: JobRecord, nowMs: number = Date.now()): number | null {
  if (String(job?.status || '').toLowerCase() === 'expired') return null
  const last = parseLastDate(job?.lastDate)
  if (!last) return null
  return Math.ceil((last.getTime() - nowMs) / DAY_MS)
}

export function isExpiringSoonJob(
  job: JobRecord,
  withinDays = EXPIRING_SOON_DAYS,
  nowMs: number = Date.now()
): boolean {
  if (String(job?.status || '').toLowerCase() === 'expired') return false
  const last = parseLastDate(job?.lastDate)
  if (!last) return false
  const daysLeft = Math.ceil((last.getTime() - nowMs) / DAY_MS)
  return daysLeft >= 0 && daysLeft <= withinDays
}

export function partitionClosingDeadlineJobs(
  jobs: JobRecord[],
  nowMs: number = Date.now()
): { today: JobRecord[]; tomorrow: JobRecord[]; week: JobRecord[] } {
  const open = jobs.filter((job) => !isJobExpired(job, nowMs))
  const todayIso = indiaDateIso(nowMs)
  const tomorrowIso = addCalendarDays(todayIso, 1)
  const today = open.filter((job) => jobLastDateIso(job) === todayIso)
  const tomorrow = open.filter((job) => jobLastDateIso(job) === tomorrowIso)
  const week = open.filter((job) => isExpiringSoonJob(job, EXPIRING_SOON_DAYS, nowMs))
  const byDate = (a: JobRecord, b: JobRecord) => {
    const da = parseLastDate(a.lastDate)?.getTime() ?? 0
    const db = parseLastDate(b.lastDate)?.getTime() ?? 0
    return da - db
  }
  return {
    today: [...today].sort(byDate),
    tomorrow: [...tomorrow].sort(byDate),
    week: [...week].sort(byDate),
  }
}

export type LatestNotifJobFilterWithClock = LatestNotifJobFilter & { nowMs?: number }

export function filterLatestNotificationJobs(
  jobs: JobRecord[],
  {
    stateId = null,
    categoryId = null,
    professionSlug = null,
    quickFilter = null,
    expiringOnly = false,
    expiringWithinDays = EXPIRING_SOON_DAYS,
    deadlineWindow = 'all',
    deadlineDate = null,
    nowMs = Date.now(),
  }: LatestNotifJobFilterWithClock
): JobRecord[] {
  let rows = jobs.filter((job) => !isJobExpired(job, nowMs))

  if (stateId === 'all') {
    rows = rows.filter((job) => jobMatchesNationwideFilter(job))
  } else if (stateId) {
    rows = rows.filter((job) => jobMatchesLatestNotifStateFilter(job, stateId))
  }

  const professionDef = getProfessionBySlug(professionSlug)
  if (professionDef) {
    rows = rows.filter((job) => jobMatchesProfession(job, professionDef))
  } else if (categoryId) {
    rows = rows.filter((job) => resolveJobCategory(job) === categoryId)
  }

  if (quickFilter) {
    rows = rows.filter((job) => {
      if ((job as { eduFilterKey?: string }).eduFilterKey === quickFilter) return true
      const q = resolveJobQualification(job)
      if (q.key === quickFilter) return true
      return jobMatchesEducationFilterKey(job, quickFilter)
    })
  }

  if (deadlineWindow === 'today') {
    const todayIso = indiaDateIso(nowMs)
    rows = rows.filter((job) => jobLastDateIso(job) === todayIso)
  } else if (deadlineWindow === 'tomorrow') {
    const tomorrowIso = addCalendarDays(indiaDateIso(nowMs), 1)
    rows = rows.filter((job) => jobLastDateIso(job) === tomorrowIso)
  } else if (deadlineWindow === 'date' && deadlineDate) {
    rows = rows.filter((job) => jobLastDateIso(job) === deadlineDate)
  } else if (deadlineWindow === 'week' || expiringOnly) {
    rows = rows.filter((job) => isExpiringSoonJob(job, expiringWithinDays, nowMs))
  }

  return rows
}

export function countJobsByState(jobs: JobRecord[]): Record<string, number> {
  const counts: Record<string, number> = { all: 0 }
  for (const job of jobs) {
    if (jobMatchesNationwideFilter(job)) counts.all = (counts.all || 0) + 1
    const matched = new Set<string>()
    const ids = job?.stateIds
    if (Array.isArray(ids)) {
      for (const id of ids) {
        if (!id || id === 'all') continue
        if (getLatestNotifStateChip(id)) matched.add(id)
      }
      if (ids.includes('ne')) {
        const sub = neSubstateFromJob(job)
        if (sub) matched.add(sub)
      }
    }
    for (const id of matched) {
      counts[id] = (counts[id] || 0) + 1
    }
  }
  return counts
}
