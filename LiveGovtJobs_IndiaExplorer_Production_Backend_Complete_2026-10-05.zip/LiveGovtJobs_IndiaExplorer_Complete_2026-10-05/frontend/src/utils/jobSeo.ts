import { SITE_DESCRIPTION, SITE_NAME, SITE_OG_IMAGE_PATH } from "@/data/siteMeta";
import { getSiteOrigin } from "@/data/siteLinks";
import { STATES } from "@/data/states";
import type { JobRecord } from "@/types/job";
import { jobDetailUrl } from "@/utils/jobRoutes";
import { jobSeoDescription } from "@/utils/scrubSeoText";
import { beginSeoHead } from "@/utils/seoHead";

const DEFAULT_DESCRIPTION = SITE_DESCRIPTION;
const NATIONWIDE_RE = /^(all[\s-]?india|india|nationwide|pan[\s-]?india)$/i;

function jobDescription(job: JobRecord): string {
  const summary =
    typeof job.detail === "object" && job.detail && "summary" in job.detail
      ? String((job.detail as { summary?: string }).summary || "")
      : "";
  const dept = String(job.dept || "").trim();
  const qual = String(job.qual || job.qualification || "").trim();
  return (
    jobSeoDescription({
      summary,
      about: job.about,
      title: job.title,
      dept,
      qualification: qual,
    }) || DEFAULT_DESCRIPTION
  );
}

function defaultOgImage(job?: JobRecord | null): string {
  const origin = getSiteOrigin();
  if (job?.slug || job?.id) {
    return `${origin}/api/og?title=${encodeURIComponent(String(job.title || "Govt Job").slice(0, 80))}`;
  }
  return `${origin}${SITE_OG_IMAGE_PATH}`;
}

function parseIsoDate(value: unknown): string | undefined {
  const raw = String(value ?? "").trim();
  if (!raw || raw === "—") return undefined;
  const d = new Date(raw);
  if (Number.isNaN(d.getTime())) return undefined;
  return d.toISOString().slice(0, 10);
}

function indiaDateIso(): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return `${values.year}-${values.month}-${values.day}`;
}

/** Google JobPosting requires datePosted — never omit it. */
function resolveDatePosted(job: JobRecord): string {
  return (
    parseIsoDate(job.published_at) ||
    parseIsoDate(job.publishedDate) ||
    parseIsoDate(job.updatedDate) ||
    parseIsoDate(job.updated_at) ||
    parseIsoDate(job.created_at) ||
    parseIsoDate(job.createdAt) ||
    new Date().toISOString().slice(0, 10)
  );
}

function stateNameFromId(id: string): string | undefined {
  return STATES.find((s) => s.id === id.toLowerCase())?.n;
}

function detailString(job: JobRecord, keys: string[]): string {
  const detail = job.detail;
  if (!detail || typeof detail !== "object") return "";
  const row = detail as Record<string, unknown>;
  for (const key of keys) {
    const value = String(row[key] ?? "").trim();
    if (value && value !== "—") return value;
  }
  return "";
}

/**
 * Resolve PostalAddress fields for every job.
 * Google recommends addressLocality + addressCountry; we always emit both.
 */
export function resolveJobPostalAddress(job: JobRecord): {
  addressLocality: string;
  addressRegion: string;
  addressCountry: "IN";
} {
  const explicitLocality = String(
    job.city || job.location || job.district || detailString(job, ["city", "location", "district", "place"])
  ).trim();

  const fromStateField = String(job.state || "").trim();
  const fromCodes = Array.isArray(job.stateIds)
    ? job.stateIds
        .map((id) => stateNameFromId(String(id)))
        .filter((n): n is string => Boolean(n))
    : [];
  const fromRawCodes = Array.isArray(job.state_codes)
    ? (job.state_codes as unknown[])
        .map((id) => stateNameFromId(String(id)))
        .filter((n): n is string => Boolean(n))
    : [];

  const regionCandidate =
    (fromStateField && !NATIONWIDE_RE.test(fromStateField) ? fromStateField : "") ||
    fromCodes[0] ||
    fromRawCodes[0] ||
    "";

  const isNationwide =
    !regionCandidate ||
    NATIONWIDE_RE.test(fromStateField) ||
    (Array.isArray(job.stateIds) && job.stateIds.includes("all"));

  const addressRegion = isNationwide ? "India" : regionCandidate;
  const addressLocality =
    explicitLocality ||
    (isNationwide ? "India" : regionCandidate.split(",")[0]?.trim() || addressRegion);

  return {
    addressLocality,
    addressRegion,
    addressCountry: "IN",
  };
}

function resolveApplyUrl(job: JobRecord): string | undefined {
  const candidates = [job.apply_url, job.applyUrl, job.officialUrl];
  for (const raw of candidates) {
    const url = String(raw || "").trim();
    if (url && url !== "#" && /^https?:\/\//i.test(url)) return url;
  }
  return undefined;
}

/** Emit Google-compatible end-of-day India time. */
export function resolveValidThrough(job: JobRecord, datePosted: string): string {
  const fromLast = parseIsoDate(job.lastDate ?? job.last_date);
  if (fromLast) return `${fromLast}T23:59:59+05:30`;
  const base = new Date(`${datePosted}T00:00:00Z`);
  if (Number.isNaN(base.getTime())) {
    const fallback = new Date();
    fallback.setUTCDate(fallback.getUTCDate() + 180);
    return `${fallback.toISOString().slice(0, 10)}T23:59:59+05:30`;
  }
  base.setUTCDate(base.getUTCDate() + 180);
  return `${base.toISOString().slice(0, 10)}T23:59:59+05:30`;
}

function parseMoneyToken(raw: string): number | undefined {
  const cleaned = raw.replace(/,/g, "").replace(/\s+/g, "");
  const n = Number(cleaned);
  if (!Number.isFinite(n) || n <= 0) return undefined;
  // Guard against scraped garbage (e.g. years, tiny ids)
  if (n < 100 || n > 10_000_000) return undefined;
  return Math.round(n);
}

/**
 * Parse Indian salary strings into schema.org MonetaryAmount when confident.
 * Accepts ranges even when "pay matrix" / "level" text is present, as long as
 * clear INR figures exist. Returns null when no parseable amount is found.
 */
export function parseJobBaseSalary(salary: unknown): Record<string, unknown> | null {
  const raw = String(salary ?? "").replace(/\s+/g, " ").trim();
  if (!raw || raw === "—" || raw.length > 160) return null;
  if (/not specified|see (official|notification)/i.test(raw) && !/(?:rs\.?|inr|₹)\s*[\d,]/i.test(raw)) {
    return null;
  }

  const unitText = /\b(per\s*month|p\.?\s*m\.?|monthly|\/\s*month)\b/i.test(raw)
    ? "MONTH"
    : /\b(per\s*annum|per\s*year|p\.?\s*a\.?|yearly|annually|\/\s*year)\b/i.test(raw)
      ? "YEAR"
      : "MONTH";

  const range = raw.match(
    /(?:rs\.?|inr|₹)?\s*([\d,]+(?:\.\d+)?)\s*(?:[-–—]|to)\s*(?:rs\.?|inr|₹)?\s*([\d,]+(?:\.\d+)?)/i
  );
  if (range) {
    const minValue = parseMoneyToken(range[1]);
    const maxValue = parseMoneyToken(range[2]);
    if (minValue && maxValue && maxValue >= minValue) {
      return {
        "@type": "MonetaryAmount",
        currency: "INR",
        value: { "@type": "QuantitativeValue", minValue, maxValue, unitText },
      };
    }
  }

  const single = raw.match(/(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d+)?)/i) || raw.match(/^([\d,]+(?:\.\d+)?)$/);
  if (single) {
    const value = parseMoneyToken(single[1]);
    if (value) {
      return {
        "@type": "MonetaryAmount",
        currency: "INR",
        value: { "@type": "QuantitativeValue", value, unitText },
      };
    }
  }

  return null;
}

const GOOGLE_CREDENTIAL_CATEGORIES = [
  "high school",
  "associate degree",
  "bachelor degree",
  "professional certificate",
  "postgraduate degree",
] as const;

type GoogleCredentialCategory = (typeof GOOGLE_CREDENTIAL_CATEGORIES)[number];

/**
 * Map Indian govt qualification text → Google JobPosting educationRequirements.
 * Free-form strings like "Graduate" trigger GSC "Invalid enum value"; emit
 * EducationalOccupationalCredential with an allowed credentialCategory, or
 * "no requirements", or omit (null) when we cannot map confidently.
 */
export function mapEducationRequirements(
  qualification: unknown
): Record<string, unknown> | Record<string, unknown>[] | "no requirements" | null {
  const raw = String(qualification ?? "").replace(/\s+/g, " ").trim();
  if (!raw || raw === "—" || /^see\b/i.test(raw)) return null;

  const lower = raw.toLowerCase();
  if (
    /\b(no (educational )?requirement|not required|any (person|candidate)|8th\s*pass|literate only)\b/i.test(
      lower
    )
  ) {
    return "no requirements";
  }

  const categories = new Set<GoogleCredentialCategory>();

  const isPostgrad =
    /\b(ph\.?\s*d|doctorate|post[\s-]?grad(?:uate)?|p\.?\s*g\.?\b|masters?|m\.?\s*a\.?\b|m\.?\s*sc|m\.?\s*com|m\.?\s*tech|m\.?\s*e\.?\b|mba|llm|md\b)\b/i.test(
      lower
    );
  // Avoid matching the "graduate" inside "post graduate"
  const isBachelor =
    /\b(bachelor|b\.?\s*a\.?\b|b\.?\s*sc|b\.?\s*com|b\.?\s*tech|b\.?\s*e\.?\b|b\.?\s*pharm|llb|mbbs|ug\b)\b/i.test(
      lower
    ) ||
    (/\b(graduate|graduation|degree)\b/i.test(lower) && !isPostgrad);

  if (isPostgrad) categories.add("postgraduate degree");
  if (isBachelor) categories.add("bachelor degree");
  if (/\b(diploma|polytechnic|iti|certificate|ncvt|apprentice)\b/i.test(lower)) {
    categories.add("professional certificate");
  }
  if (/\b(associate)\b/i.test(lower)) {
    categories.add("associate degree");
  }
  if (
    /\b(10th|12th|matric|hsc|ssc|intermediate|\+2|senior secondary|higher secondary|class\s*(?:10|12)|xth|xiith)\b/i.test(
      lower
    )
  ) {
    categories.add("high school");
  }

  if (categories.size === 0) return null;

  const ordered = GOOGLE_CREDENTIAL_CATEGORIES.filter((c) => categories.has(c));
  const credentials = ordered.map((credentialCategory) => ({
    "@type": "EducationalOccupationalCredential",
    credentialCategory,
  }));
  return credentials.length === 1 ? credentials[0] : credentials;
}

/** Only emit street/PIN when the job record actually has them — never invent. */
function resolveOptionalStreetFields(job: JobRecord): {
  streetAddress?: string;
  postalCode?: string;
} {
  const streetAddress = String(
    job.streetAddress ||
      job.street_address ||
      detailString(job, ["streetAddress", "street_address", "office_address", "address", "hq_address"])
  ).trim();
  let postalCode = String(
    job.postalCode ||
      job.postal_code ||
      job.pincode ||
      detailString(job, ["postalCode", "postal_code", "pincode", "pin"])
  ).trim();

  // Pull a 6-digit PIN out of a longer address string when present.
  if (!/^\d{6}$/.test(postalCode)) {
    const pinMatch = `${streetAddress} ${postalCode}`.match(/\b(\d{6})\b/);
    if (pinMatch) postalCode = pinMatch[1];
  }

  const out: { streetAddress?: string; postalCode?: string } = {};
  const hasStreetHint =
    /\b(road|rd\.?|street|st\.?|lane|marg|nagar|complex|bhawan|bhavan|sector|plot|floor|building|office|hq|headquarters|block|hill)\b/i.test(
      streetAddress
    );
  const looksLikeStreet =
    streetAddress.length >= 8 &&
    streetAddress.length <= 200 &&
    !NATIONWIDE_RE.test(streetAddress) &&
    (!/^[A-Za-z\s]+$/.test(streetAddress) || hasStreetHint);

  if (streetAddress && (looksLikeStreet || hasStreetHint) && streetAddress.length >= 5) {
    const cleaned = streetAddress.replace(/\b\d{6}\b/, "").replace(/[,\s]+$/g, "").trim();
    out.streetAddress = cleaned || streetAddress;
  }
  if (/^\d{6}$/.test(postalCode)) out.postalCode = postalCode;
  return out;
}

/** True when the listing is a real recruitment (not schedule/merit/circular/hackathon). */
export function isRecruitmentJobPosting(job: JobRecord): boolean {
  const title = String(job.title || "").toLowerCase();
  const slug = String(job.slug || "").toLowerCase();
  const blob = `${title} ${slug}`;

  const nonJob =
    /\b(exam\s*schedule|tentative\s*exam|admit\s*card|hall\s*ticket|merit\s*list|cutoff|cut[\s-]?off|result\s*notice|answer\s*key|circular\s*order|corrigendum|hackathon|teams?\s*selected|seating\s*plan|press\s*(?:note|release)|shortlist(?:ing|ed)?\s*for\s*medical|provisionally\s*(?:in-?)?eligible|travel\s*allowance\s*form)\b/i.test(
      blob
    );
  if (nonJob) return false;

  const vacancies = Number(job.vacancies) || 0;
  if (vacancies > 0) return true;

  return /\b(recruit(?:ment|ing)?|vacanc(?:y|ies)|apply\s*(?:online|offline)|walk[\s-]?in|notification\s*for\s*(?:the\s*)?post|posts?\s+of|engagement\s+of|hiring)\b/i.test(
    blob
  );
}

/** Structured job data is allowed only for the approved, unexpired public state. */
export function isApprovedActiveJobPosting(job: JobRecord, today = indiaDateIso()): boolean {
  const lastDate = parseIsoDate(job.lastDate ?? job.last_date);
  return (
    String(job.status || "").toLowerCase() === "live" &&
    job.published_to_site === true &&
    String(job.document_type || "").toUpperCase() === "RECRUITMENT" &&
    ["VERIFIED", "PARTIALLY_VERIFIED"].includes(
      String(job.verification_status || "").toUpperCase()
    ) &&
    Number(job.completeness_score) >= 70 &&
    Number(job.publication_confidence) >= 90 &&
    Boolean(lastDate && lastDate >= today) &&
    isRecruitmentJobPosting(job)
  );
}

export function buildJobPostingJsonLd(job: JobRecord): Record<string, unknown> | null {
  if (!job.title) return null;
  // Only emit JobPosting for real recruitments. Notices like exam schedules,
  // merit lists, circulars, and hackathons are still browsable pages — but
  // marking them as JobPosting makes Google expect baseSalary/street forever.
  if (!isApprovedActiveJobPosting(job)) return null;
  const url = jobDetailUrl(job);
  const datePosted = resolveDatePosted(job);
  const validThrough = resolveValidThrough(job, datePosted);
  const address = resolveJobPostalAddress(job);
  const streetFields = resolveOptionalStreetFields(job);
  const applyUrl = resolveApplyUrl(job);
  const orgName = String(job.dept || "Government of India recruitment");

  const hiringOrganization: Record<string, unknown> = {
    "@type": "Organization",
    name: orgName,
  };
  if (applyUrl) hiringOrganization.sameAs = applyUrl;

  const postalAddress: Record<string, unknown> = {
    "@type": "PostalAddress",
    addressLocality: address.addressLocality,
    addressRegion: address.addressRegion,
    addressCountry: address.addressCountry,
  };
  if (streetFields.streetAddress) postalAddress.streetAddress = streetFields.streetAddress;
  if (streetFields.postalCode) postalAddress.postalCode = streetFields.postalCode;

  const posting: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": "JobPosting",
    title: job.title,
    description: jobDescription(job),
    datePosted,
    validThrough,
    hiringOrganization,
    jobLocation: {
      "@type": "Place",
      address: postalAddress,
    },
    employmentType: "FULL_TIME",
    industry: "Government",
    url: url || undefined,
  };

  if (job.id || job.slug) {
    posting.identifier = {
      "@type": "PropertyValue",
      name: SITE_NAME,
      value: String(job.id || job.slug),
    };
  }

  const dateModified = parseIsoDate(job.updatedDate ?? job.updated_at);
  if (dateModified) posting.dateModified = dateModified;
  if (Number(job.vacancies) > 0) {
    posting.totalJobOpenings = Number(job.vacancies);
  }

  const baseSalary = parseJobBaseSalary(job.salary);
  if (baseSalary) posting.baseSalary = baseSalary;

  const education = mapEducationRequirements(job.qual || job.qualification);
  if (education) posting.educationRequirements = education;

  return posting;
}

export function applyJobSeo(job: JobRecord | null) {
  const jsonLdId = "job-posting-jsonld";
  const head = beginSeoHead();
  const fallbackTitle = `${SITE_NAME} — Latest Government Jobs India`;

  if (!job?.title) {
    head.setTitle(fallbackTitle);
    head.upsertMeta("description", DEFAULT_DESCRIPTION);
    head.upsertMeta("og:site_name", SITE_NAME, "property");
    head.upsertMeta("og:title", fallbackTitle, "property");
    head.upsertMeta("og:description", DEFAULT_DESCRIPTION, "property");
    head.upsertMeta("og:image", defaultOgImage(), "property");
    head.upsertMeta("robots", "index, follow, max-image-preview:large");
    return head.restore;
  }

  const title = `${job.title} | ${SITE_NAME}`;
  const description = jobDescription(job);
  const url = jobDetailUrl(job) || window.location.href;
  const ogImage = defaultOgImage(job);

  head.setTitle(title);
  head.upsertMeta("description", description);
  head.upsertMeta("og:site_name", SITE_NAME, "property");
  head.upsertMeta("og:locale", "en_IN", "property");
  head.upsertMeta("og:title", title, "property");
  head.upsertMeta("og:description", description, "property");
  head.upsertMeta("og:type", "article", "property");
  head.upsertMeta("og:url", url, "property");
  head.upsertMeta("og:image", ogImage, "property");
  head.upsertMeta("twitter:card", "summary_large_image", "name");
  head.upsertMeta("twitter:image", ogImage, "name");
  head.upsertMeta("twitter:title", title, "name");
  head.upsertMeta("twitter:description", description, "name");
  head.upsertLink("canonical", url);
  head.upsertMeta("robots", "index, follow, max-image-preview:large");

  const jsonLd = buildJobPostingJsonLd(job);
  if (jsonLd) {
    head.upsertJsonLd(jsonLdId, jsonLd);
  }

  return head.restore;
}
