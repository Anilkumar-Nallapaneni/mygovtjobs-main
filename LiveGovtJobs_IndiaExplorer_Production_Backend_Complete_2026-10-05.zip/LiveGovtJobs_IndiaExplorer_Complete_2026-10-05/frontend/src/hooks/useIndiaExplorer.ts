import { useEffect, useState } from 'react'
import { fetchIndiaCategory, fetchIndiaOverview, fetchIndiaState, fetchIndiaStates, type IndiaOverview, type IndiaRecord, type IndiaState } from '@/lib/indiaApi'

export function useIndiaOverview() {
  const [data, setData] = useState<IndiaOverview | null>(null)
  const [loading, setLoading] = useState(true)
  useEffect(() => { let active = true; fetchIndiaOverview().then(value => { if (active) setData(value) }).catch(() => undefined).finally(() => { if (active) setLoading(false) }); return () => { active = false } }, [])
  return { data, loading }
}

export function useIndiaStates() {
  const [data, setData] = useState<IndiaState[] | null>(null)
  const [loading, setLoading] = useState(true)
  useEffect(() => { let active = true; fetchIndiaStates().then(value => { if (active) setData(value) }).catch(() => undefined).finally(() => { if (active) setLoading(false) }); return () => { active = false } }, [])
  return { data, loading }
}

export function useIndiaState(stateId: string) {
  const [data, setData] = useState<(IndiaState & { counts: { districts: number; cities: number; places: number }; source_name?: string; source_url?: string }) | null>(null)
  const [loading, setLoading] = useState(true)
  useEffect(() => { let active = true; setLoading(true); fetchIndiaState(stateId).then(value => { if (active) setData(value) }).catch(() => undefined).finally(() => { if (active) setLoading(false) }); return () => { active = false } }, [stateId])
  return { data, loading }
}

export function useIndiaCategory(stateId: string, categoryId: string) {
  const [data, setData] = useState<{ items: IndiaRecord[]; total: number; category: string; message?: string } | null>(null)
  const [loading, setLoading] = useState(Boolean(categoryId))
  useEffect(() => {
    if (!categoryId) { setData(null); setLoading(false); return }
    let active = true
    setLoading(true)
    fetchIndiaCategory(stateId, categoryId, { limit: 60 }).then(value => { if (active) setData(value) }).catch(() => undefined).finally(() => { if (active) setLoading(false) })
    return () => { active = false }
  }, [stateId, categoryId])
  return { data, loading }
}
