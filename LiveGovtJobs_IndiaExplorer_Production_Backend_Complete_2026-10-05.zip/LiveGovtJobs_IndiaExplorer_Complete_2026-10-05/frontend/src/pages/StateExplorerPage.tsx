import { Link, useParams } from 'react-router-dom';
import { IndiaMap } from '@/components/Maps/IndiaMap/IndiaMap';
import { getExplorerProfile, getExplorerState, EXPLORER_CATEGORIES } from '@/data/india/indiaExplorer';
import { toSvgStateId } from '@/data/states';
import ExplorerCategoryCard from '@/components/india/ExplorerCategoryCard';
import { useIndiaCategory, useIndiaState } from '@/hooks/useIndiaExplorer';
import '@/styles/india-explorer.css';

export default function StateExplorerPage() {
  const { stateId = '', category: categoryId = '' } = useParams();
  const state = getExplorerState(stateId);
  if (!state) return <main className="india-explorer india-explorer--empty"><h1>State not found</h1><Link to="/india">Return to India Map</Link></main>;
  const profile = getExplorerProfile(state.id);
  const selectedCategory = EXPLORER_CATEGORIES.find((category) => category.id === categoryId);
  const categoryData: Record<string, string[]> = {
    agriculture: profile.crops,
    industries: profile.industries,
    tourism: profile.tourism,
    companies: profile.industries,
    temples: profile.tourism,
    jobs: ['Government jobs', 'Private jobs', 'Apprenticeships', 'Internships'],
    education: ['Schools', 'Colleges', 'Universities', 'Exams', 'Scholarships'],
    hotels: ['Hotels and stays', 'City accommodation', 'Tourism hubs'],
    hospitals: ['Hospitals', 'Healthcare facilities', 'District health services'],
    transport: ['Airports', 'Railway stations', 'Road and transport hubs'],
    schemes: ['Central government schemes', 'State government schemes', 'Citizen services'],
    gk: ['State facts', 'Geography', 'History', 'Culture', 'General knowledge'],
  };
  const selectedItems = selectedCategory ? (categoryData[selectedCategory.id] || []) : [];
  const { data: apiState, loading: stateLoading } = useIndiaState(state.id);
  const { data: categoryResult, loading: categoryLoading } = useIndiaCategory(state.id, selectedCategory?.id || '');
  return (
    <main className="india-explorer">
      <section className="state-explorer__header">
        <div><Link to="/india" className="india-explorer__back">← India Map</Link><span className="india-explorer__eyebrow">STATE EXPLORER</span><h1>{state.n}</h1><p>{profile.highlights.join(' • ')}</p></div>
        <div className="state-explorer__badge"><strong>{state.ab}</strong><span>{state.reg === 'northeast' ? 'North East' : state.reg[0].toUpperCase() + state.reg.slice(1)}</span></div>
      </section>

      <section className="state-explorer__overview">
        <div className="state-explorer__map"><IndiaMap isolateStateId={toSvgStateId(state.id)} mapStyle={{ stroke: 'transparent', strokeWidth: 0, hoverColor: '#dbe4ef', backgroundColor: '#f4f7fb' }} /></div>
        <div className="state-explorer__facts"><h2>At a glance</h2><div className="state-explorer__fact-grid"><div><span>Capital</span><strong>{apiState?.capital || (state.n === 'Delhi' ? 'New Delhi' : 'Official profile')}</strong></div><div><span>Region</span><strong>{apiState?.region || state.reg}</strong></div><div><span>Verified districts</span><strong>{stateLoading ? 'Loading…' : apiState?.counts.districts ?? 0}</strong></div><div><span>Verified places</span><strong>{stateLoading ? 'Loading…' : apiState?.counts.places ?? 0}</strong></div></div><h3>Major cities</h3><div className="state-explorer__chips">{profile.cities.map((city) => <span key={city}>{city}</span>)}</div></div>
      </section>

      {selectedCategory && (
        <section className="state-explorer__spotlight" aria-labelledby="state-category-title">
          <div className="state-explorer__spotlight-copy">
            <span className="india-explorer__eyebrow">STATE CATEGORY</span>
            <h2 id="state-category-title">{selectedCategory.icon} {selectedCategory.title} in {state.n}</h2>
            <p>{selectedCategory.description}</p>
          </div>
          <div className="state-explorer__spotlight-list">
            {categoryLoading && <span>Loading verified records…</span>}
            {!categoryLoading && categoryResult?.items?.length ? categoryResult.items.slice(0, 12).map((item) => (
              <a key={item.id} href={item.website || item.source_url || '#'} target={item.website || item.source_url ? '_blank' : undefined} rel="noreferrer">
                <strong>{item.name}</strong>
                <small>{[item.city_name, item.district_name].filter(Boolean).join(' • ') || item.category}</small>
              </a>
            )) : !categoryLoading && selectedItems.map((item) => <span key={item}>{item}</span>)}
          </div>
        </section>
      )}

      <section><div className="india-explorer__section-head"><div><h2>Everything in {state.n}</h2><p>Each category is a separate layer so the app stays fast and easy to use.</p></div></div><div className="india-explorer__category-grid india-explorer__category-grid--cards">{EXPLORER_CATEGORIES.map((category) => <ExplorerCategoryCard key={category.id} category={category} stateId={state.id} />)}</div></section>

      <section className="state-explorer__detail-grid">
        <article><h2>🌾 Agriculture</h2><div className="state-explorer__chips">{profile.crops.map((item) => <span key={item}>{item}</span>)}</div></article>
        <article><h2>🏭 Industries</h2><div className="state-explorer__chips">{profile.industries.map((item) => <span key={item}>{item}</span>)}</div></article>
        <article><h2>🧭 Tourism</h2><div className="state-explorer__chips">{profile.tourism.map((item) => <span key={item}>{item}</span>)}</div></article>
      </section>
    </main>
  );
}
