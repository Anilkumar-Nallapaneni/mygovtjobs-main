import { Link, useParams } from 'react-router-dom';
import { IndiaMap } from '@/components/Maps/IndiaMap/IndiaMap';
import { getExplorerProfile, getExplorerState, EXPLORER_CATEGORIES } from '@/data/india/indiaExplorer';
import { toSvgStateId } from '@/data/states';
import ExplorerCategoryCard from '@/components/india/ExplorerCategoryCard';
import '@/styles/india-explorer.css';

export default function StateExplorerPage() {
  const { stateId = '' } = useParams();
  const state = getExplorerState(stateId);
  if (!state) return <main className="india-explorer india-explorer--empty"><h1>State not found</h1><Link to="/india">Return to India Map</Link></main>;
  const profile = getExplorerProfile(state.id);
  return (
    <main className="india-explorer">
      <section className="state-explorer__header">
        <div><Link to="/india" className="india-explorer__back">← India Map</Link><span className="india-explorer__eyebrow">STATE EXPLORER</span><h1>{state.n}</h1><p>{profile.highlights.join(' • ')}</p></div>
        <div className="state-explorer__badge"><strong>{state.ab}</strong><span>{state.reg === 'northeast' ? 'North East' : state.reg[0].toUpperCase() + state.reg.slice(1)}</span></div>
      </section>

      <section className="state-explorer__overview">
        <div className="state-explorer__map"><IndiaMap isolateStateId={toSvgStateId(state.id)} mapStyle={{ stroke: 'transparent', strokeWidth: 0, hoverColor: '#dbe4ef', backgroundColor: '#f4f7fb' }} /></div>
        <div className="state-explorer__facts"><h2>At a glance</h2><div className="state-explorer__fact-grid"><div><span>Capital</span><strong>{state.n === 'Delhi' ? 'New Delhi' : 'See state profile'}</strong></div><div><span>Region</span><strong>{state.reg}</strong></div><div><span>Major crops</span><strong>{profile.crops.slice(0, 3).join(', ') || 'Service economy'}</strong></div><div><span>Key industries</span><strong>{profile.industries.slice(0, 3).join(', ')}</strong></div></div><h3>Major cities</h3><div className="state-explorer__chips">{profile.cities.map((city) => <span key={city}>{city}</span>)}</div></div>
      </section>

      <section><div className="india-explorer__section-head"><div><h2>Everything in {state.n}</h2><p>Each category is a separate layer so the app stays fast and easy to use.</p></div></div><div className="india-explorer__category-grid india-explorer__category-grid--cards">{EXPLORER_CATEGORIES.map((category) => <ExplorerCategoryCard key={category.id} category={category} stateId={state.id} />)}</div></section>

      <section className="state-explorer__detail-grid">
        <article><h2>🌾 Agriculture</h2><div className="state-explorer__chips">{profile.crops.map((item) => <span key={item}>{item}</span>)}</div></article>
        <article><h2>🏭 Industries</h2><div className="state-explorer__chips">{profile.industries.map((item) => <span key={item}>{item}</span>)}</div></article>
        <article><h2>🧭 Tourism</h2><div className="state-explorer__chips">{profile.tourism.map((item) => <span key={item}>{item}</span>)}</div></article>
      </section>
    </main>
  );
}
