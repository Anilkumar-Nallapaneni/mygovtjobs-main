import { STATES } from '@/data/states';

export type ExplorerCategoryId =
  | 'jobs' | 'education' | 'agriculture' | 'industries' | 'companies'
  | 'tourism' | 'temples' | 'hotels' | 'hospitals' | 'transport'
  | 'schemes' | 'gk';

export type ExplorerCategory = {
  id: ExplorerCategoryId;
  title: string;
  description: string;
  icon: string;
  route?: string;
};

export type StateExplorerProfile = {
  stateId: string;
  highlights: string[];
  crops: string[];
  industries: string[];
  tourism: string[];
  cities: string[];
  searchTerms: string[];
};

export const EXPLORER_CATEGORIES: ExplorerCategory[] = [
  { id: 'jobs', title: 'Jobs', description: 'Government jobs, private opportunities, apprenticeships and internships.', icon: '💼', route: '/jobs' },
  { id: 'education', title: 'Education', description: 'Schools, colleges, universities, courses, exams and scholarships.', icon: '🎓', route: '/education' },
  { id: 'agriculture', title: 'Agriculture', description: 'Major crops, farming regions, horticulture, livestock and markets.', icon: '🌾' },
  { id: 'industries', title: 'Industries', description: 'Major industrial sectors, clusters and manufacturing activity.', icon: '🏭' },
  { id: 'companies', title: 'Companies', description: 'Companies, employers, factories and business locations.', icon: '🏢' },
  { id: 'tourism', title: 'Tourism', description: 'Tourist destinations, wildlife, beaches, mountains and heritage.', icon: '🧭' },
  { id: 'temples', title: 'Temples & Heritage', description: 'Temples, monuments, forts and cultural landmarks.', icon: '🛕' },
  { id: 'hotels', title: 'Hotels', description: 'Hotels and stays organized by state, district and city.', icon: '🏨' },
  { id: 'hospitals', title: 'Hospitals', description: 'Healthcare facilities and hospitals by location.', icon: '🏥' },
  { id: 'transport', title: 'Transport', description: 'Airports, railway stations, highways and major transport hubs.', icon: '🚆' },
  { id: 'schemes', title: 'Government Schemes', description: 'Central and state welfare schemes and official resources.', icon: '🏛️', route: '/yojana' },
  { id: 'gk', title: 'General Knowledge', description: 'State facts, geography, history, culture and competitive-exam GK.', icon: '📚' },
];

const PROFILE: Record<string, Omit<StateExplorerProfile, 'stateId'>> = {
  ap: { highlights: ['Coastal state', 'Krishna and Godavari river systems', 'Major port and aquaculture economy'], crops: ['Rice', 'Chilli', 'Tobacco', 'Groundnut', 'Horticulture'], industries: ['Food processing', 'Pharmaceuticals', 'Automobiles', 'Textiles', 'Ports & logistics'], tourism: ['Visakhapatnam', 'Tirupati', 'Araku Valley', 'Amaravati'], cities: ['Visakhapatnam', 'Vijayawada', 'Tirupati', 'Guntur'], searchTerms: ['andhra pradesh', 'ap'] },
  ar: { highlights: ['Eastern Himalayan state', 'High forest cover', 'Mountain and river ecosystems'], crops: ['Rice', 'Maize', 'Millets', 'Horticulture', 'Orange'], industries: ['Hydropower', 'Handicrafts', 'Food processing', 'Tourism'], tourism: ['Tawang', 'Ziro Valley', 'Itanagar', 'Namdapha'], cities: ['Itanagar', 'Tawang', 'Pasighat'], searchTerms: ['arunachal pradesh', 'arunachal'] },
  as: { highlights: ['Brahmaputra valley', 'Tea-producing region', 'Rich biodiversity'], crops: ['Tea', 'Rice', 'Jute', 'Mustard', 'Sugarcane'], industries: ['Tea', 'Oil & gas', 'Food processing', 'Handloom', 'Tourism'], tourism: ['Kaziranga', 'Guwahati', 'Majuli', 'Sivasagar'], cities: ['Guwahati', 'Dibrugarh', 'Jorhat'], searchTerms: ['assam'] },
  br: { highlights: ['Ganga plains', 'Historic learning centres', 'Large agricultural base'], crops: ['Rice', 'Wheat', 'Maize', 'Sugarcane', 'Litchi'], industries: ['Food processing', 'Textiles', 'Leather', 'Manufacturing', 'Services'], tourism: ['Bodh Gaya', 'Nalanda', 'Patna', 'Rajgir'], cities: ['Patna', 'Gaya', 'Muzaffarpur', 'Bhagalpur'], searchTerms: ['bihar'] },
  cg: { highlights: ['Central Indian forest belt', 'Mineral-rich state', 'Major rice-growing areas'], crops: ['Rice', 'Maize', 'Pulses', 'Oilseeds', 'Horticulture'], industries: ['Steel', 'Power', 'Mining', 'Cement', 'Food processing'], tourism: ['Chitrakote', 'Bastar', 'Sirpur', 'Barnawapara'], cities: ['Raipur', 'Bhilai', 'Bilaspur', 'Jagdalpur'], searchTerms: ['chhattisgarh'] },
  ga: { highlights: ['Konkan coast', 'Beach tourism', 'Small but diverse economy'], crops: ['Rice', 'Cashew', 'Coconut', 'Horticulture'], industries: ['Tourism', 'Pharmaceuticals', 'Food processing', 'Mining'], tourism: ['Panaji', 'Calangute', 'Old Goa', 'Dudhsagar'], cities: ['Panaji', 'Vasco da Gama', 'Margao'], searchTerms: ['goa'] },
  gj: { highlights: ['Long Arabian Sea coastline', 'Industrial and trading hub', 'Strong renewable-energy potential'], crops: ['Cotton', 'Groundnut', 'Wheat', 'Cumin', 'Castor'], industries: ['Petrochemicals', 'Pharmaceuticals', 'Textiles', 'Engineering', 'Ports'], tourism: ['Ahmedabad', 'Gir', 'Rann of Kutch', 'Somnath'], cities: ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot'], searchTerms: ['gujarat'] },
  hr: { highlights: ['National Capital Region connectivity', 'Strong agriculture', 'Automobile manufacturing cluster'], crops: ['Wheat', 'Rice', 'Mustard', 'Cotton', 'Sugarcane'], industries: ['Automobiles', 'IT', 'Manufacturing', 'Logistics', 'Food processing'], tourism: ['Gurugram', 'Kurukshetra', 'Panipat', 'Sultanpur'], cities: ['Gurugram', 'Faridabad', 'Panipat', 'Hisar'], searchTerms: ['haryana'] },
  hp: { highlights: ['Western Himalayas', 'Hill agriculture and horticulture', 'Hydropower potential'], crops: ['Apple', 'Maize', 'Wheat', 'Potato', 'Stone fruits'], industries: ['Tourism', 'Pharmaceuticals', 'Hydropower', 'Food processing'], tourism: ['Shimla', 'Manali', 'Dharamshala', 'Spiti'], cities: ['Shimla', 'Dharamshala', 'Solan', 'Mandi'], searchTerms: ['himachal pradesh', 'himachal'] },
  jh: { highlights: ['Mineral-rich plateau', 'Forest resources', 'Major mining and steel base'], crops: ['Rice', 'Maize', 'Pulses', 'Oilseeds', 'Vegetables'], industries: ['Steel', 'Mining', 'Power', 'Engineering', 'Cement'], tourism: ['Ranchi', 'Deoghar', 'Netarhat', 'Betla'], cities: ['Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro'], searchTerms: ['jharkhand'] },
  ka: { highlights: ['Major technology and manufacturing hub', 'Coffee-growing regions', 'Diverse economy'], crops: ['Coffee', 'Ragi', 'Rice', 'Sugarcane', 'Maize'], industries: ['IT & software', 'Automobiles', 'Aerospace', 'Biotech', 'Manufacturing'], tourism: ['Bengaluru', 'Mysuru', 'Coorg', 'Hampi'], cities: ['Bengaluru', 'Mysuru', 'Mangaluru', 'Hubballi'], searchTerms: ['karnataka', 'bangalore', 'bengaluru'] },
  kl: { highlights: ['Western Ghats and Arabian Sea coast', 'High human-development indicators', 'Strong tourism economy'], crops: ['Coconut', 'Rubber', 'Pepper', 'Rice', 'Banana'], industries: ['Tourism', 'IT', 'Food processing', 'Healthcare', 'Marine'], tourism: ['Kochi', 'Munnar', 'Alappuzha', 'Thiruvananthapuram'], cities: ['Kochi', 'Kozhikode', 'Thiruvananthapuram', 'Thrissur'], searchTerms: ['kerala'] },
  mp: { highlights: ['Central Indian heartland', 'Large forest and agricultural regions', 'Major heritage sites'], crops: ['Soybean', 'Wheat', 'Gram', 'Rice', 'Maize'], industries: ['Automobiles', 'Pharmaceuticals', 'Cement', 'Mining', 'Food processing'], tourism: ['Khajuraho', 'Bhopal', 'Kanha', 'Ujjain'], cities: ['Indore', 'Bhopal', 'Jabalpur', 'Gwalior'], searchTerms: ['madhya pradesh', 'mp'] },
  mh: { highlights: ['Major financial and industrial economy', 'Large western coastline', 'Diverse agriculture'], crops: ['Sugarcane', 'Cotton', 'Soybean', 'Grapes', 'Onion'], industries: ['Finance', 'IT', 'Automobiles', 'Pharmaceuticals', 'Entertainment'], tourism: ['Mumbai', 'Pune', 'Ajanta', 'Mahabaleshwar'], cities: ['Mumbai', 'Pune', 'Nagpur', 'Nashik'], searchTerms: ['maharashtra'] },
  mn: { highlights: ['Northeastern hill state', 'Loktak Lake ecosystem', 'Handloom and sports traditions'], crops: ['Rice', 'Maize', 'Pulses', 'Horticulture'], industries: ['Handloom', 'Handicrafts', 'Food processing', 'Tourism'], tourism: ['Imphal', 'Loktak Lake', 'Kangla', 'Keibul Lamjao'], cities: ['Imphal', 'Thoubal'], searchTerms: ['manipur'] },
  ml: { highlights: ['Shillong plateau', 'High rainfall region', 'Living root bridge heritage'], crops: ['Rice', 'Pineapple', 'Turmeric', 'Ginger', 'Horticulture'], industries: ['Tourism', 'Mining', 'Food processing', 'Handicrafts'], tourism: ['Shillong', 'Cherrapunji', 'Mawlynnong', 'Nongpoh'], cities: ['Shillong', 'Tura', 'Jowai'], searchTerms: ['meghalaya'] },
  mz: { highlights: ['Mountainous northeastern state', 'Bamboo and horticulture resources', 'Strong cultural diversity'], crops: ['Bamboo', 'Rice', 'Ginger', 'Turmeric', 'Horticulture'], industries: ['Handicrafts', 'Bamboo', 'Food processing', 'Tourism'], tourism: ['Aizawl', 'Champhai', 'Lunglei', 'Reiek'], cities: ['Aizawl', 'Lunglei', 'Champhai'], searchTerms: ['mizoram'] },
  nl: { highlights: ['Northeastern hill state', 'Rich tribal cultures', 'Hornbill festival destination'], crops: ['Rice', 'Maize', 'Pulses', 'Horticulture'], industries: ['Handloom', 'Handicrafts', 'Food processing', 'Tourism'], tourism: ['Kohima', 'Dimapur', 'Dzukou Valley', 'Hornbill Festival'], cities: ['Kohima', 'Dimapur', 'Mokokchung'], searchTerms: ['nagaland'] },
  od: { highlights: ['Eastern coastline', 'Temple heritage', 'Major mineral and industrial base'], crops: ['Rice', 'Pulses', 'Groundnut', 'Oilseeds', 'Vegetables'], industries: ['Metals', 'Mining', 'Power', 'IT', 'Food processing'], tourism: ['Puri', 'Bhubaneswar', 'Konark', 'Chilika'], cities: ['Bhubaneswar', 'Cuttack', 'Rourkela', 'Puri'], searchTerms: ['odisha', 'orissa'] },
  pb: { highlights: ['Indo-Gangetic agricultural heartland', 'Strong food-grain production', 'Major historical sites'], crops: ['Wheat', 'Rice', 'Cotton', 'Maize', 'Sugarcane'], industries: ['Food processing', 'Textiles', 'Light engineering', 'Sports goods'], tourism: ['Amritsar', 'Anandpur Sahib', 'Ludhiana', 'Patiala'], cities: ['Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala'], searchTerms: ['punjab'] },
  rj: { highlights: ['Largest Indian state by area', 'Desert and arid ecosystems', 'Heritage tourism powerhouse'], crops: ['Bajra', 'Wheat', 'Mustard', 'Guar', 'Cumin'], industries: ['Mining', 'Cement', 'Textiles', 'Gems & jewellery', 'Tourism'], tourism: ['Jaipur', 'Udaipur', 'Jaisalmer', 'Jodhpur'], cities: ['Jaipur', 'Jodhpur', 'Udaipur', 'Kota'], searchTerms: ['rajasthan'] },
  sk: { highlights: ['Himalayan state', 'High-altitude agriculture', 'Biodiversity and eco-tourism'], crops: ['Large cardamom', 'Ginger', 'Rice', 'Maize', 'Horticulture'], industries: ['Tourism', 'Food processing', 'Pharmaceuticals', 'Hydropower'], tourism: ['Gangtok', 'Pelling', 'Tsomgo Lake', 'Nathula'], cities: ['Gangtok', 'Namchi', 'Gyalshing'], searchTerms: ['sikkim'] },
  tn: { highlights: ['Major manufacturing and services economy', 'Long eastern coastline', 'Large education ecosystem'], crops: ['Rice', 'Sugarcane', 'Cotton', 'Banana', 'Coconut'], industries: ['Automobiles', 'Electronics', 'Textiles', 'IT', 'Engineering'], tourism: ['Chennai', 'Madurai', 'Ooty', 'Rameswaram'], cities: ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli'], searchTerms: ['tamil nadu', 'tamilnadu'] },
  tg: { highlights: ['Deccan plateau', 'Hyderabad technology and pharma hub', 'Major irrigation projects'], crops: ['Rice', 'Cotton', 'Maize', 'Soybean', 'Turmeric'], industries: ['IT', 'Pharmaceuticals', 'Biotech', 'Aerospace', 'Manufacturing'], tourism: ['Hyderabad', 'Warangal', 'Yadadri', 'Nagarjuna Sagar'], cities: ['Hyderabad', 'Warangal', 'Nizamabad', 'Karimnagar'], searchTerms: ['telangana', 'hyderabad'] },
  tr: { highlights: ['Northeastern hill state', 'Bamboo and rubber resources', 'Rich archaeological heritage'], crops: ['Rice', 'Rubber', 'Pineapple', 'Tea', 'Jackfruit'], industries: ['Rubber', 'Food processing', 'Bamboo', 'Tourism'], tourism: ['Agartala', 'Unakoti', 'Neermahal', 'Sepahijala'], cities: ['Agartala', 'Udaipur', 'Dharmanagar'], searchTerms: ['tripura'] },
  up: { highlights: ['India\'s most populous state', 'Ganga-Yamuna plains', 'Large education and manufacturing base'], crops: ['Wheat', 'Rice', 'Sugarcane', 'Potato', 'Pulses'], industries: ['Food processing', 'Leather', 'Textiles', 'Electronics', 'Defence manufacturing'], tourism: ['Agra', 'Varanasi', 'Ayodhya', 'Lucknow'], cities: ['Lucknow', 'Kanpur', 'Varanasi', 'Agra'], searchTerms: ['uttar pradesh', 'up'] },
  uk: { highlights: ['Himalayan state', 'Pilgrimage and eco-tourism', 'Hydropower and horticulture'], crops: ['Rice', 'Wheat', 'Mandua', 'Apple', 'Horticulture'], industries: ['Tourism', 'Pharmaceuticals', 'Food processing', 'Hydropower'], tourism: ['Dehradun', 'Rishikesh', 'Haridwar', 'Kedarnath'], cities: ['Dehradun', 'Haridwar', 'Haldwani', 'Rishikesh'], searchTerms: ['uttarakhand', 'uttaranchal'] },
  wb: { highlights: ['Ganga-Brahmaputra delta region', 'Major cultural and commercial centre', 'Strong agriculture and services'], crops: ['Rice', 'Jute', 'Tea', 'Potato', 'Vegetables'], industries: ['IT', 'Jute', 'Engineering', 'Food processing', 'Ports & logistics'], tourism: ['Kolkata', 'Darjeeling', 'Sundarbans', 'Digha'], cities: ['Kolkata', 'Howrah', 'Siliguri', 'Durgapur'], searchTerms: ['west bengal', 'kolkata'] },
  dl: { highlights: ['National capital territory', 'Major administrative and service economy', 'Large education and healthcare ecosystem'], crops: [], industries: ['Government', 'IT', 'Finance', 'Healthcare', 'Education'], tourism: ['Red Fort', 'India Gate', 'Qutub Minar', 'Lotus Temple'], cities: ['New Delhi', 'Delhi'], searchTerms: ['delhi', 'new delhi'] },
  jk: { highlights: ['Himalayan and valley landscapes', 'Major horticulture region', 'Pilgrimage and tourism'], crops: ['Apple', 'Rice', 'Wheat', 'Saffron', 'Walnut'], industries: ['Tourism', 'Horticulture', 'Handicrafts', 'Food processing'], tourism: ['Srinagar', 'Gulmarg', 'Pahalgam', 'Jammu'], cities: ['Srinagar', 'Jammu', 'Anantnag'], searchTerms: ['jammu kashmir', 'jammu and kashmir'] },
  la: { highlights: ['High-altitude Himalayan region', 'Unique mountain ecology', 'Adventure and cultural tourism'], crops: ['Barley', 'Wheat', 'Peas', 'Horticulture'], industries: ['Tourism', 'Handicrafts', 'Renewable energy', 'Food processing'], tourism: ['Leh', 'Nubra', 'Pangong', 'Kargil'], cities: ['Leh', 'Kargil'], searchTerms: ['ladakh'] },
  an: { highlights: ['Island territory', 'Marine biodiversity', 'Strategic maritime location'], crops: ['Coconut', 'Arecanut', 'Rice', 'Banana'], industries: ['Tourism', 'Fisheries', 'Marine services', 'Coconut products'], tourism: ['Port Blair', 'Swaraj Dweep', 'Baratang', 'Cellular Jail'], cities: ['Port Blair'], searchTerms: ['andaman nicobar', 'andaman and nicobar'] },
  ch: { highlights: ['Planned union territory city', 'Major administrative and education centre', 'Shared capital of Punjab and Haryana'], crops: [], industries: ['Government', 'Education', 'Healthcare', 'Services'], tourism: ['Rock Garden', 'Sukhna Lake', 'Capitol Complex'], cities: ['Chandigarh'], searchTerms: ['chandigarh'] },
  dd: { highlights: ['Western coastal union territory', 'Industrial and tourism activity', 'Two geographic components'], crops: ['Rice', 'Coconut', 'Pulses'], industries: ['Pharmaceuticals', 'Textiles', 'Food processing', 'Tourism'], tourism: ['Daman', 'Diu Fort', 'Nagoa Beach', 'Silvassa'], cities: ['Daman', 'Diu', 'Silvassa'], searchTerms: ['dadra nagar haveli daman diu', 'daman diu'] },
  ld: { highlights: ['Arabian Sea island territory', 'Marine ecosystems', 'Tourism and fisheries'], crops: ['Coconut', 'Tuna and marine fisheries'], industries: ['Tourism', 'Fisheries', 'Coir'], tourism: ['Kavaratti', 'Agatti', 'Bangaram'], cities: ['Kavaratti'], searchTerms: ['lakshadweep'] },
  py: { highlights: ['Coastal union territory', 'French colonial heritage', 'Education and tourism centre'], crops: ['Rice', 'Groundnut', 'Pulses', 'Sugarcane'], industries: ['Tourism', 'Textiles', 'Food processing', 'Services'], tourism: ['Puducherry', 'Auroville', 'Promenade', 'Heritage Quarter'], cities: ['Puducherry', 'Karaikal'], searchTerms: ['puducherry', 'pondicherry'] },
};

const FALLBACK: Omit<StateExplorerProfile, 'stateId'> = {
  highlights: ['Explore official state information', 'Education and employment ecosystem', 'Tourism, culture and local services'],
  crops: ['Rice', 'Wheat', 'Pulses', 'Oilseeds', 'Horticulture'],
  industries: ['Manufacturing', 'Services', 'Food processing', 'Small & medium enterprises'],
  tourism: ['Capital city', 'Heritage locations', 'Nature and cultural attractions'],
  cities: [],
  searchTerms: [],
};

export function getExplorerProfile(stateId: string): StateExplorerProfile {
  const state = STATES.find((item) => item.id === stateId);
  const profile = PROFILE[stateId] ?? FALLBACK;
  return { stateId, ...profile, searchTerms: [...profile.searchTerms, state?.n ?? ''].filter(Boolean) };
}

export function getExplorerState(stateId: string) {
  return STATES.find((state) => state.id === stateId && state.id !== 'ne') ?? null;
}

export const EXPLORER_STATE_IDS = STATES.filter((state) => state.id !== 'ne').map((state) => state.id);
