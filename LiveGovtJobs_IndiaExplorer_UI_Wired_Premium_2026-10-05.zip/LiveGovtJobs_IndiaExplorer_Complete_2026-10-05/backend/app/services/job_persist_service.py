"""Persist normalized ingest rows to Postgres and JSON snapshot for the UI."""

import json
import logging
import os
from datetime import date, datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

from sqlalchemy import case, select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.models.job import Job, Source
from app.services.dedupe_service import content_hash, title_fingerprint
from app.services.document_classifier import classify_document, classify_from_normalized
from app.services.job_completeness_service import calculate_completeness
from app.services.job_persist_helpers import (
    _PUBLIC_VERIFICATION_STATUSES,
    _atomic_write_text,
    _below_public_catalog_floor,
    _database_host_label,
    _is_dramatic_snapshot_drop,
    _parse_date,
    _public_catalog_floor,
    _resolve_published_at,
    _resolve_source_url,
    _resolve_state_codes,
    _resolve_vacancies,
    _should_preserve_public_gate_on_conflict,
    _snapshot_looks_like_ungated_feed_dump,
    _source_domain,
    _upsert_published_at,
    slugify,
)
from app.services.noise_filter import (
    clean_job_title,
    clean_plain_text,
    sanitize_json_for_postgres,
    sanitize_source_text_fields,
    strip_postgres_control_chars,
)
from app.services.live_snapshot_clean import filter_live_snapshot_items
from app.services.pdf_candidate import select_primary_pdf
from app.services.publish_gate import ValidationResult, resolve_persist_status, validate_job_for_publication
from app.utils.catalog_job_count import count_catalog_display_jobs
from app.utils.slim_detail import slim_detail_for_db
from app.utils.live_jobs_export import slim_job_for_json_export, slim_job_for_list_json_export

# Re-export helpers so existing `from app.services.job_persist_service import …` keeps working.
__all__ = [
    "JobPersistService",
    "slugify",
    "_atomic_write_text",
    "_parse_date",
    "_resolve_state_codes",
    "_resolve_published_at",
    "_upsert_published_at",
    "_resolve_vacancies",
    "_resolve_source_url",
    "_source_domain",
    "_should_preserve_public_gate_on_conflict",
    "_is_dramatic_snapshot_drop",
    "_below_public_catalog_floor",
    "_database_host_label",
    "_snapshot_looks_like_ungated_feed_dump",
]

class JobPersistService:
    async def _existing_job_for_identity(
        self,
        session: AsyncSession,
        *,
        digest: str,
        source_url: str | None,
    ) -> Job | None:
        existing = await session.execute(select(Job).where(Job.content_hash == digest).limit(1))
        job = existing.scalar_one_or_none()
        if job or not source_url:
            return job

        existing = await session.execute(select(Job).where(Job.source_url == source_url).limit(1))
        return existing.scalar_one_or_none()

    @staticmethod
    def _keep_existing_public_gate(job: Job) -> bool:
        return (
            getattr(job, "status", None) == "live"
            and bool(getattr(job, "published_to_site", False))
            and getattr(job, "verification_status", None) in _PUBLIC_VERIFICATION_STATUSES
        )

    async def upsert_normalized(self, session: AsyncSession, normalized: dict, *, commit: bool = True) -> Job | None:
        raw_payload = sanitize_json_for_postgres(dict(normalized))
        normalized = sanitize_source_text_fields(normalized)
        title = clean_job_title(normalized.get("title"))
        if not title:
            from app.services.job_review_service import JobReviewService

            await JobReviewService().enqueue(
                session,
                raw_payload=raw_payload,
                normalized_payload=normalized,
                validation=ValidationResult(
                    valid=False,
                    errors=["Missing title after sanitization"],
                    confidence=0,
                ),
                source_url=_resolve_source_url(normalized, normalized.get("apply_url")),
            )
            if commit:
                await session.commit()
            return None

        settings = get_settings()
        apply_url = strip_postgres_control_chars(normalized.get("apply_url")) or None
        last_date = _parse_date(normalized.get("last_date"))
        if last_date is None:
            from app.parsers.pdf_dates import extract_dates_from_text

            detail_blob = normalized.get("detail") if isinstance(normalized.get("detail"), dict) else {}
            date_blob = " ".join(
                part
                for part in (
                    title,
                    str(normalized.get("qualification") or ""),
                    str(detail_blob.get("summary") or ""),
                    str(detail_blob.get("how_to_apply") or ""),
                    str(detail_blob.get("important_dates") or ""),
                )
                if part
            )
            extracted = extract_dates_from_text(date_blob)
            last_date = _parse_date(extracted.get("last_date"))
        digest = normalized.get("content_hash") or content_hash(
            title=title, apply_url=apply_url, last_date=str(last_date or "")
        )
        dept = clean_plain_text(normalized.get("dept") or normalized.get("organization")) or None
        published_at = _upsert_published_at(normalized)
        source_url = _resolve_source_url(normalized, apply_url)
        source_code = str(normalized.get("source") or normalized.get("source_code") or "").strip()
        source_id = None
        if source_code:
            source_id = (
                await session.execute(select(Source.id).where(Source.code == source_code).limit(1))
            ).scalar_one_or_none()
        slug = normalized.get("slug") or slugify(
            title,
            digest,
            dept=dept,
            published_year=published_at.year if published_at else None,
            source_url=source_url,
        )
        state_codes = _resolve_state_codes(normalized)

        document_type = (
            str(normalized.get("document_type") or "").strip().upper()
            or classify_from_normalized({**normalized, "title": title, "apply_url": apply_url, "dept": dept})
        )
        explicit_verification = str(normalized.get("verification_status") or "").strip().upper() or None

        classification = classify_document(
            title,
            str((normalized.get("detail") or {}).get("summary") or ""),
            url=str(apply_url or source_url or ""),
            dept=str(dept or ""),
        )
        if not document_type or document_type == "UNKNOWN":
            document_type = classification.document_type

        completeness_score, missing_fields = calculate_completeness(
            {
                **normalized,
                "title": title,
                "dept": dept,
                "apply_url": apply_url,
                "source_url": source_url,
                "last_date": last_date,
                "vacancies": _resolve_vacancies(normalized),
            }
        )
        review_reasons = list(normalized.get("review_reasons") or [])
        if classification.reasons:
            review_reasons.extend(classification.reasons)
        if missing_fields:
            review_reasons.append(f"Missing fields: {', '.join(missing_fields[:8])}")
        if classification.content_type != "RECRUITMENT":
            review_reasons.append(f"Classifier: {classification.content_type}")

        detail_for_pdf = normalized.get("detail") if isinstance(normalized.get("detail"), dict) else {}
        pdf_candidates = (
            list(detail_for_pdf.get("pdf_urls") or detail_for_pdf.get("pdfUrls") or [])
            + ([apply_url] if apply_url and ".pdf" in apply_url.lower() else [])
        )
        primary_pdf, pdf_score, _ = select_primary_pdf(pdf_candidates, min_score=0)
        if pdf_score < 0:
            review_reasons.append(f"No positive primary PDF (best score={pdf_score})")
            primary_pdf = None

        gate_normalized = {
            **normalized,
            "title": title,
            "dept": dept,
            "apply_url": apply_url,
            "source_url": source_url,
            "state_codes": state_codes,
            "vacancies": _resolve_vacancies(normalized),
        }
        job_status, verification_status, published_to_site, gate_errors = resolve_persist_status(
            last_date=last_date,
            document_type=document_type,
            verification_status=explicit_verification or "UNVERIFIED",
            normalized=gate_normalized,
            auto_publish_verified=bool(settings.auto_publish_verified),
            completeness_score=completeness_score,
        )
        validation = validate_job_for_publication(
            {
                **gate_normalized,
                "last_date": last_date,
                "document_type": document_type,
                "verification_status": "VERIFIED" if settings.auto_publish_verified else verification_status,
                "completeness_score": completeness_score,
            }
        )
        # Allow explicit status override only for expired (deadline) already handled;
        # never force live when auto-publish is off.
        if normalized.get("status") == "expired":
            job_status = "expired"
            published_to_site = False

        detail_blob = dict(normalized.get("detail") or {})
        post_name = clean_plain_text(normalized.get("post_name")) or None
        if post_name:
            detail_blob["post_name"] = post_name
        detail_blob["document_type"] = document_type
        detail_blob["verification_status"] = verification_status
        detail_blob["completeness_score"] = completeness_score
        detail_blob["classification"] = {
            "content_type": classification.content_type,
            "confidence": classification.confidence,
            "reasons": classification.reasons,
        }
        if primary_pdf:
            detail_blob["primary_pdf_url"] = primary_pdf
            detail_blob["pdf_url"] = detail_blob.get("pdf_url") or primary_pdf

        vacancies = _resolve_vacancies(normalized)

        row = {
            "slug": slug,
            "title": title,
            "dept": dept,
            "category": clean_plain_text(normalized.get("category")) or None,
            "state_codes": state_codes,
            "vacancies": vacancies,
            "qualification": clean_plain_text(normalized.get("qualification")) or None,
            "salary": clean_plain_text(normalized.get("salary")) or None,
            "age_limit": clean_plain_text(normalized.get("age_limit")) or None,
            "last_date": last_date,
            "apply_url": apply_url,
            "status": job_status,
            "published_at": published_at,
            "normalized_at": datetime.now(timezone.utc),
            "content_hash": digest,
            "title_fingerprint": title_fingerprint(title),
            "detail": sanitize_json_for_postgres(slim_detail_for_db(detail_blob, status=job_status)),
            "document_type": document_type,
            "verification_status": verification_status,
            "completeness_score": completeness_score,
            "published_to_site": published_to_site,
            "primary_pdf_url": primary_pdf,
            "source_evidence": sanitize_json_for_postgres(
                normalized.get("source_evidence")
                if isinstance(normalized.get("source_evidence"), dict)
                else {}
            ),
            "review_reasons": sanitize_json_for_postgres(review_reasons[:40]),
            "source_url": source_url,
            "source_id": str(source_id) if source_id else None,
            "source_domain": _source_domain(source_url),
            "confidence_score": classification.confidence,
            "publication_confidence": validation.confidence,
        }

        preserve_public_gate = None
        if _should_preserve_public_gate_on_conflict(
            status=row["status"],
            published_to_site=row["published_to_site"],
        ):
            preserve_public_gate = (
                (Job.status == "live")
                & (Job.published_to_site.is_(True))
                & (Job.verification_status.in_(_PUBLIC_VERIFICATION_STATUSES))
            )

        def preserve_gate_value(value, existing_column):
            if preserve_public_gate is None:
                return value
            return case((preserve_public_gate, existing_column), else_=value)

        last_date_update = preserve_gate_value(row["last_date"], Job.last_date)
        vacancies_update = preserve_gate_value(row["vacancies"], Job.vacancies)

        update_values = {
            "title": row["title"],
            "dept": row["dept"],
            "category": row["category"],
            "state_codes": row["state_codes"],
            "vacancies": vacancies_update,
            "last_date": last_date_update,
            "apply_url": row["apply_url"],
            "published_at": row["published_at"],
            "normalized_at": row["normalized_at"],
            "detail": row["detail"],
            "status": preserve_gate_value(row["status"], Job.status),
            "title_fingerprint": row["title_fingerprint"],
            "document_type": preserve_gate_value(row["document_type"], Job.document_type),
            "verification_status": preserve_gate_value(row["verification_status"], Job.verification_status),
            "completeness_score": preserve_gate_value(row["completeness_score"], Job.completeness_score),
            "published_to_site": preserve_gate_value(row["published_to_site"], Job.published_to_site),
            "primary_pdf_url": row["primary_pdf_url"],
            "source_evidence": row["source_evidence"],
            "review_reasons": row["review_reasons"],
            "source_url": row["source_url"],
            "source_id": row["source_id"],
            "source_domain": row["source_domain"],
            "confidence_score": row["confidence_score"],
            "publication_confidence": preserve_gate_value(
                row["publication_confidence"],
                Job.publication_confidence,
            ),
        }

        gate_fields = {
            "status",
            "document_type",
            "verification_status",
            "completeness_score",
            "published_to_site",
            "publication_confidence",
        }

        persisted_job = await self._existing_job_for_identity(
            session, digest=digest, source_url=source_url
        )
        if persisted_job:
            keep_gate = preserve_public_gate is not None and self._keep_existing_public_gate(
                persisted_job
            )
            python_updates = {
                **{
                    key: row[key]
                    for key in update_values
                    if key not in gate_fields or not keep_gate
                },
                "slug": row["slug"],
                "content_hash": row["content_hash"],
            }
            # Never clobber live dates/vacancies with a scrape that would have demoted the row.
            if keep_gate:
                python_updates.pop("last_date", None)
                python_updates.pop("vacancies", None)
            elif row["last_date"] is None:
                python_updates.pop("last_date", None)
            for key, value in python_updates.items():
                setattr(persisted_job, key, value)
            await session.flush()
        else:
            stmt = (
                insert(Job)
                .values(**row)
                .on_conflict_do_update(
                    index_elements=[Job.content_hash],
                    set_=update_values,
                )
                .returning(Job)
            )
            result = await session.execute(stmt)
            persisted_job = result.scalar_one_or_none()
        if persisted_job is not None and not bool(getattr(persisted_job, "published_to_site", False)):
            from app.services.job_review_service import JobReviewService

            quarantine_errors = list(dict.fromkeys([*gate_errors, *validation.errors]))
            await JobReviewService().enqueue(
                session,
                raw_payload=raw_payload,
                normalized_payload={**normalized, **row},
                validation=ValidationResult(
                    valid=False,
                    errors=quarantine_errors or ["Manual approval required"],
                    warnings=validation.warnings,
                    confidence=validation.confidence,
                ),
                source_url=source_url,
                fingerprint=digest,
            )
        if commit:
            await session.commit()
        return persisted_job

    async def export_live_jobs_json(self, session: AsyncSession) -> int:
        from app.services.job_service import JobService

        service = JobService()
        items = []
        offset = 0
        page_size = 1000
        total = None
        while total is None or offset < total:
            page, total = await service.list_jobs(limit=page_size, offset=offset, session=session)
            if not page:
                break
            items.extend(page)
            offset += len(page)

        slim_items = [slim_job_for_json_export(item) for item in items]
        list_items = [slim_job_for_list_json_export(item) for item in items]
        before_strict = len(slim_items)
        slim_items, dropped_strict = filter_live_snapshot_items(slim_items)
        if dropped_strict:
            logger.warning(
                "export_live_jobs_json: strict snapshot filter dropped %s/%s rows",
                dropped_strict,
                before_strict,
            )
            kept_slugs = {str(row.get("slug") or "") for row in slim_items}
            list_items = [row for row in list_items if str(row.get("slug") or "") in kept_slugs]
        catalog_count = count_catalog_display_jobs(slim_items)
        settings = get_settings()
        db_host = _database_host_label(settings.database_url)
        logger.info(
            "export_live_jobs_json: host=%s queried=%s gated=%s",
            db_host,
            before_strict,
            len(slim_items),
        )
        print(
            f"export_live_jobs_json: database host={db_host} "
            f"queried={before_strict} gated={len(slim_items)}",
            flush=True,
        )

        # Guard against overwriting the shipped catalog with an empty or
        # below-floor payload. ALLOW_DRASTIC_JSON_EXPORT does not bypass this.
        # Set ALLOW_EMPTY_JSON_EXPORT=1 only for an intentional wipe.
        if _below_public_catalog_floor(len(slim_items)):
            floor = _public_catalog_floor()
            msg = (
                f"export_live_jobs_json: refusing to write {len(slim_items)}-row snapshot "
                f"(host={db_host}); minimum release floor is {floor}. "
                "Point DATABASE_URL at the production catalog or set "
                "ALLOW_EMPTY_JSON_EXPORT=1 to override."
            )
            logger.error(msg)
            raise RuntimeError(msg)

        daily_block: dict = {}
        try:
            from app.services.daily_sync_service import DailySyncService

            state = DailySyncService()._read()
            if state.get("status") == "completed":
                daily_block = {
                    "completedAt": state.get("completedAt"),
                    "completedAtIst": state.get("completedAtIst"),
                    "dateIst": state.get("lastCompletedDateIst"),
                    "nextRunAtIst": state.get("nextRunAtIst"),
                    "jobCount": catalog_count,
                    "sourcesScraped": state.get("sourcesScraped"),
                    "scheduledLabel": "8:00 AM IST daily",
                }
        except Exception:
            pass

        payload = {
            "generatedAt": datetime.now(timezone.utc).isoformat(),
            "dailySync": daily_block or None,
            "items": slim_items,
        }
        path = Path(settings.live_jobs_json_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        existing_count: int | None = None
        existing_payload: dict | None = None
        if path.exists():
            try:
                existing_payload = json.loads(path.read_text(encoding="utf-8"))
                existing_items = existing_payload.get("items")
                if isinstance(existing_items, list):
                    existing_count = len(existing_items)
            except Exception:
                existing_count = None
                existing_payload = None
        allow_drastic = os.environ.get("ALLOW_DRASTIC_JSON_EXPORT") == "1"
        replacing_feed_dump = _snapshot_looks_like_ungated_feed_dump(existing_payload)
        if (
            _is_dramatic_snapshot_drop(existing_count, len(slim_items))
            and not allow_drastic
            and not replacing_feed_dump
        ):
            msg = (
                f"export_live_jobs_json: refusing to replace {existing_count}-row snapshot "
                f"with {len(slim_items)} rows. Set ALLOW_DRASTIC_JSON_EXPORT=1 to override."
            )
            logger.error(msg)
            raise RuntimeError(msg)
        if replacing_feed_dump and existing_count and existing_count != len(slim_items):
            logger.warning(
                "export_live_jobs_json: replacing ungated feed dump (%s rows) with gated export (%s rows)",
                existing_count,
                len(slim_items),
            )
        _atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2))

        list_path = path.with_name("live-jobs-list.json")
        list_payload = {
            "generatedAt": payload["generatedAt"],
            "dailySync": payload["dailySync"],
            "items": list_items,
        }
        _atomic_write_text(
            list_path,
            json.dumps(list_payload, ensure_ascii=False, separators=(",", ":")),
        )
        return catalog_count

    def patch_live_jobs_daily_sync(self, block: dict) -> None:
        """Update dailySync in live-jobs.json after mark_completed (export runs while still 'running')."""
        if not block:
            return
        path = Path(get_settings().live_jobs_json_path)
        if not path.exists():
            return
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            payload["dailySync"] = block
            _atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2))
        except Exception:
            logger.warning("patch_live_jobs_daily_sync failed for %s", path, exc_info=True)
