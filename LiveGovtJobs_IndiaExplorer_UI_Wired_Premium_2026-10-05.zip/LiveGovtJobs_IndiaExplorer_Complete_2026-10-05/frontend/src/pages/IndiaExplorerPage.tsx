import { useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { IndiaMap } from '@/components/Maps/IndiaMap/IndiaMap';
import { STATES, toSvgStateId } from '@/data/states';
import { EXPLORER_CATEGORIES, EXPLORER_STATE_IDS } from '@/data/india/indiaExplorer';
import ExplorerCategoryCard from '@/components/india/ExplorerCategoryCard';
import '@/styles/india-explorer.css';

export default function IndiaExplorerPage() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [searchParams, setSearchParams] = useSearchParams();
  const [activeLayer, setActiveLayer] = useState(searchParams.get('layer') || '');
  const states = useMemo(() => STATES.filter((state) => EXPLORER_STATE_IDS.includes(state.id)), []);
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return states;
    return states.filter((state) => `${state.n} ${state.ab}`.toLowerCase().includes(q));
  }, [query, states]);
  const setLayer = (layer: string) => {
    const next = layer === activeLayer ? '' : layer;
    setActiveLayer(next);
    const params = new URLSearchParams(searchParams);
    if (next) params.set('layer', next); else params.delete('layer');
    setSearchParams(params, { replace: true });
  };

  const stateData = useMemo(() => states.map((state) => ({
    id: toSvgStateId(state.id),
    name: state.n,
    fill: '#e9eef5',
    customData: { name: state.n, jobCount: 0, listings: 'Explore' },
  })), [states]);

  return (
    <div className="india-explorer">
      <section className="india-explorer__hero">
        <div>
          <span className="india-explorer__eyebrow">ONE INDIA PLATFORM</span>
          <h1>Explore India on one interactive map</h1>
          <p>Jobs, education, agriculture, companies, industries, tourism, temples, hotels, transport and general knowledge — organized by state, district and city.</p>
          <label className="india-explorer__search">
            <span aria-hidden="true">⌕</span>
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search a state or Union Territory" aria-label="Search state or Union Territory" />
          </label>
        </div>
        <div className="india-explorer__hero-stat"><strong>36</strong><span>States & Union Territories</span></div>
      </section>

      <section className="india-explorer__map-layout">
        <div className="india-explorer__map-card">
          <div className="india-explorer__section-head"><div><h2>India map</h2><p>Click a state to open its complete explorer.</p></div><span className="india-explorer__live-dot">● Interactive</span></div>
          <IndiaMap
            stateData={stateData}
            mapStyle={{ stroke: '#94a3b8', strokeWidth: 1.2, hoverColor: '#cbd5e1', backgroundColor: '#eef2f7' }}
            onStateClick={(svgId) => {
              const id = STATES.find((state) => toSvgStateId(state.id) === svgId)?.id;
              if (id && id !== 'ne') navigate(`/india/${id}`);
            }}
          />
        </div>
        <aside className="india-explorer__state-list">
          <div className="india-explorer__section-head"><div><h2>States & UTs</h2><p>{filtered.length} available</p></div></div>
          <div className="india-explorer__state-grid">
            {filtered.map((state) => <button key={state.id} type="button" onClick={() => navigate(`/india/${state.id}`)}>{state.n}<span>{state.ab}</span></button>)}
          </div>
        </aside>
      </section>

      <section className="india-explorer__layers">
        <div className="india-explorer__section-head"><div><h2>Explore by category</h2><p>Use one platform for every major India information category.</p></div></div>
        <div className="india-explorer__category-grid">
          {EXPLORER_CATEGORIES.map((category) => <button key={category.id} type="button" className={activeLayer === category.id ? 'india-layer-filter india-layer-filter--active' : 'india-layer-filter'} onClick={() => setLayer(category.id)}>{category.icon} {category.title}</button>)}
        </div>
        <div className="india-explorer__category-grid india-explorer__category-grid--cards">
          {EXPLORER_CATEGORIES.filter((category) => !activeLayer || category.id === activeLayer).map((category) => <ExplorerCategoryCard key={category.id} category={category} />)}
        </div>
      </section>
    </div>
  );
}
